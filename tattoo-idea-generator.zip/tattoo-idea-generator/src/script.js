var adjectives = ["surreal", "bloody", "wavy", "melting", "flower", "creeping", "menacing", "smiling", "dancing", "thorny", "flying", "skeletal", "phantom", "mysterious", "burning", "smoking", "hanging", "pixelated", "disintegrating", "clownish", "floating","faery-land","mystical", "light-filled", "amorous"];
var conjunctions = ["in front of a", "pierced by a", "over a", "wrapped around a", "under a", "and a", "with a", "looking at a", "inside of a", "holding a", "below a", "fighting a", "trying to escape a", "dancing with a", "swimming with a", "flying alongside a", "swinging amongst a"];
var nouns = ["skull", "dagger", "snake", "cobra", "moon", "sun", "palm", "cobweb", "set of stairs", "window", "candlestick", "hand", "veil", "eye", "mermaid", "bottle", "sword", "castle", "princess", "prince", "wizard", "star", "apple", "cherry", "torso", "curtain", "tiger", "dog", "bird", "rose", "clock", "tower", "spider", "chain", "ruin", "nunchaku", "frog", "lizard", "dinosaur","lightning","mountain","organ", "cauldron", "dragon", "carrot", "haunted house", "religious figure", "demi-god", "demon", "wristwatch", "flag", "keyboard", "notebook", "key", "telephone", "murder of crows", "koala", "school of fish" ];
var shownText = document.getElementById("generatedText");

function generateIdea() {
  document.getElementById("generatedText").style.color = "#800000";
  var adjective1 = adjectives[Math.floor(Math.random()*adjectives.length)];
  var adjective2 = adjectives[Math.floor(Math.random()*adjectives.length)];
  var conjunction1 = conjunctions[Math.floor(Math.random()*conjunctions.length)];
  var noun1 = nouns[Math.floor(Math.random()*nouns.length)];
  var noun2 = nouns[Math.floor(Math.random()*nouns.length)];
  
  var jsIsStupidArray = ['a <span onclick="generateDiff(0)">', adjective1, '</span> <span onclick="generateDiff(1)">', noun1, '</span> <span onclick="generateDiff(2)">', conjunction1, '</span> <span onclick="generateDiff(3)">', adjective2, '</span> <span onclick="generateDiff(4)">', noun2, '</span>'];
  document.getElementById("generatedText").innerHTML = jsIsStupidArray.join("");
}


function generateDiff(x) {
  switch (x) {
    case 0:
       shownText.getElementsByTagName('span')[0].innerHTML = adjectives[Math.floor(Math.random()*adjectives.length)];
      break;
      
    case 1:
      shownText.getElementsByTagName('span')[1].innerHTML = nouns[Math.floor(Math.random()*nouns.length)];
      break;
      
    case 2:
      shownText.getElementsByTagName('span')[2].innerHTML = conjunctions[Math.floor(Math.random()*conjunctions.length)];
      break;
      
    case 3:
      shownText.getElementsByTagName('span')[3].innerHTML = adjectives[Math.floor(Math.random()*adjectives.length)];
      break;
      
    case 4:
      shownText.getElementsByTagName('span')[4].innerHTML = nouns[Math.floor(Math.random()*nouns.length)];
  
    }
  }



function generateShortIdea() {
    document.getElementById("generatedText").style.color = "#800000";
    var adjective = adjectives[Math.floor(Math.random()*adjectives.length)];
    var noun = nouns[Math.floor(Math.random()*nouns.length)];
    var jsIsStupidArray2 = ['a <span onclick="generateDiff(0)">', adjective, '</span> <span onclick="generateDiff(1)">', noun];
  document.getElementById("generatedText").innerHTML = jsIsStupidArray2.join("");
}